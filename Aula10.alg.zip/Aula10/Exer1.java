import java.util.Scanner;
public class Exer1{
    static double soma (double salario, double vendas){
        double comissao = vendas * 0.04;
        System.out.println("A sua comissão desse mês é de: " + comissao);
        double total = salario + comissao;  
        return total;
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double salario, vendas;

        System.out.print("Digite seu salário: ");
        salario = entrada.nextDouble();
        System.out.print("Digite o valor das suas vendas do mês: ");
        vendas = entrada.nextDouble();

        double result = soma(salario, vendas);
        System.out.println("O seu salario e a comissão desse mês é: " + result);
    }
}