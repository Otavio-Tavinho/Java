import java.util.Scanner;
public class Exer2 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);
        String modelo[] = new String[10];
        double combust[] = new double[10];

        int i;
        double med = 0, soma = 0;

        for (i = 0; i < 10; i++){
            System.out.print("Digite o modelo do carro: ");
            modelo[i] = entrada.next();
            System.out.print("Digite o consumo de combustível: ");
            combust[i] = entrada.nextDouble();
            soma = soma + combust[i];
            med = soma / i;
        }
        System.out.println("O modelo do carro mais econômico é: "  );
        System.out.println("O consumo médio dos veículos é: " + med);

        //não consegui finalizar! eu podira fazer menor recebe menor mais n iria aparecer o modelo do carro. 
    }
}
