import java.util.Scanner;
public class Exer3 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int i, num, neg = 0, pos = 0;

        for (i = 1; i <= 10; i++){
            System.out.print("Digite um número: ");
            num = entrada.nextInt();
        
            if (num > 50 && num%2 != 0) {
                pos++;
            } else {
                neg++;
            }
        }
        System.out.println("A quantidade de números ímpares digitados são: " + pos);
        System.out.println("Quantidades de números fora da condição é: " + neg);
    }
}
