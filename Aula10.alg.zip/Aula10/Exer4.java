import java.util.Scanner;
public class Exer4 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int i, num, fat = 1, cont = 1;

        do{
            System.out.print("Digite um número: ");
            num = entrada.nextInt();

            for ( i = 1; i <= num; i++){
                fat = fat * i;
            }

            System.out.println("O valor do fatorial de: " + num + " é igual a: " + fat);

        } while (cont < 1);
    } 
}
