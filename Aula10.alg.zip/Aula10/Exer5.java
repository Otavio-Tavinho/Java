import java.util.Scanner;
public class Exer5 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);
        double temp[] = new double[12];

        int i, indMaior;
        double menor = 99, maior = 0;

        for (i = 0; i < 12; i++) {
            System.out.print("Digite a temperatura do mes: ");
            temp[i] = entrada.nextDouble();
        }
        for (i = 0; i < 12; i++){
            if (maior < temp[i]){
                maior = temp[i];
                indMaior = i;
            }
        }
         System.out.println("A menor temperatura foi no mes: " + maior);

        switch(indMaior) {
            case 0:
                System.out.println("Janeiro");
                break;
            case 1:
                System.out.println("Fevereiro");
                break;
            case 2:
                System.out.println("Março");
                break;
            case 3:
                System.out.println("Abril");
                break;
            case 4:
                System.out.println("Maio");
                break;
            case 5:
                System.out.println("Junho");
                break;        
            case 6:
                System.out.println("Julho");
                break;    
            case 7:
                System.out.println("Agosto");
                break;    
            case 8:
                System.out.println("Setembro");
                break;
            case 9:
                System.out.println("Outubro");
                break;
            case 10:
                System.out.println("Novembro");
                break;            
            case 11:
                System.out.println("Desembro");
                break;    
        }
    }
}
