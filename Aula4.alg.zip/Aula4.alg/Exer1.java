import java.util.Scanner;
public class Exer1{
    public static void main(String[] args){
        double salanovo, salatual;

        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite o número da opção desejada, para realizar o aumento de salário!");
        System.out.println("1-Escriturário\n2-Secretário\n3-Caixa\n4-Gerente\n5-Diretor");
        int opc = entrada.nextInt();
        
        switch(opc) {
            case 1:
                System.out.println("Você escolheu Escriturário");
                System.out.print("Digite o salário atual para efetuar o reajuste: ");
                salatual = entrada.nextFloat();
                salanovo = salatual * 0.5;
                System.out.println("50% de acréscimo no salário: " + salanovo);
                System.out.print("Totalizando: " + (salanovo+salatual));
                break;
            case 2:
                System.out.println("Você escolheu Secretário");
                System.out.print("Digite o salário atual para efetuar o reajuste: ");
                salatual = entrada.nextFloat();
                salanovo = salatual * 0.35;
                System.out.println("35% de acréscimo no salário: " + salanovo);
                System.out.print("Totalizando: " + (salanovo+salatual));
                break;
            case 3:
                System.out.println("Você escolheu Caixa");
                System.out.print("Digite o salário atual para efetuar o reajuste: ");
                salatual = entrada.nextFloat();
                salanovo = salatual * 0.2;
                System.out.println("20% de acréscimo no salário: " + salanovo);
                System.out.print("Totalizando: " + (salanovo+salatual));
                break;
            case 4:
                System.out.println("Você escolheu Gerente");
                System.out.print("Digite o salário atual para efetuar o reajuste: ");
                salatual = entrada.nextFloat();
                salanovo = salatual * 0.1;
                System.out.println("10% de acréscimo no salário: " + salanovo);
                System.out.print("Totalizando: " + (salanovo+salatual));
                break;
            case 5:
                System.out.println("Você escolheu Diretor");
                System.out.print("Infelizmente esse cargo não tem aumento!");
                break;                     
            default:
                System.out.print("Digite uma opção valida!");                   
        }
    }
}
