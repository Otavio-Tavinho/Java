import java.util.Scanner;
public class Exer5{
    public static void main(String[] args){
        String opc1;

        Scanner entrada = new Scanner(System.in); 
        System.out.println("Digite o número do destino desejado com a saída de São Paulo!");
        System.out.println("1-Região Norte\n2-Região Nordeste\n3-Região Centro-Oeste\n4-Região Sul\n5-Sair");
        int opc = entrada.nextInt();
   
        switch(opc){
            case 1:
                System.out.println("Você escolheu Região Norte");
                System.out.println("Você quer adicionar ida e volta [s/n]?");
                opc1 = entrada.next();
                if(opc1.equals("s")){
                    System.out.println("Ida e Volta $900");
                } else{
                    System.out.println("Somente ida $500");
                }    
                break;      
            case 2:
                System.out.println("Você escolheu Região Nordeste");
                System.out.println("Você quer adicionar ida e volta [s/n]?");
                opc1 = entrada.next();
                if(opc1.equals("s")){
                    System.out.println("Ida e Volta $650");
                } else{
                    System.out.println("Somente ida $350");
                }
                break;
            case 3:
                System.out.println("Você escolheu Região Centro-Oeste");
                System.out.println("Você quer adicionar ida e volta [s/n]?");
                opc1 = entrada.next();
                if(opc1.equals("s")){
                    System.out.println("Ida e Volta $600");
                } else{
                    System.out.println("Somente ida $300");
                } 
                break;
            case 4:
                System.out.println("Você escolheu Região Sul");
                System.out.println("Você quer adicionar ida e volta [s/n]?");
                opc1 = entrada.next();
                if(opc1.equals("s")){
                    System.out.println("Ida e Volta $550");
                } else{
                    System.out.println("Somente ida $600");
                } 
                break;
            case 5:
                System.out.println("Bye Bye");
                break;       
            default:
                System.out.println("Digite uma opção valida!");                        
        }
    }
}
