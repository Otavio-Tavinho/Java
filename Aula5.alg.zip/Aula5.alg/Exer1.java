public class Exer1{
    public static void main(String[] args){
        int cont = 0;
        while (cont <= 100) {
            cont++;
            if (cont % 2 == 0) {
                System.out.println(cont);
            }
        }
    }
}