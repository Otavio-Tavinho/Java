import java.util.Scanner;
public class Exer10 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);

        int tab, i, y;

            System.out.print("Digite um número: ");
            tab = entrada.nextInt();

        for (i = 0; i <= 10; i++){
            y = tab * i;
            System.out.println(tab + "x" + i + "=" + y);
        }
    }
}
