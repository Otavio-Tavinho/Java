import java.util.Scanner;
public class Exer3 {
    public static void main(String[] args) {
        int num;
        float cont; 
        float soma = 0;

        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Digite um número");
        num = entrada.nextInt();
       
        if (num == 0){
            System.out.println("Digite um número positivo e maior que zero!");
        }
        for (cont = 1; cont <= num; cont++) { 
            soma += 1 / cont;
            System.out.println("O resultado é: " + soma);
        }  
    }
}
