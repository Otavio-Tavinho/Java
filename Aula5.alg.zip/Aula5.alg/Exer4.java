import java.util.Scanner;
public class Exer4 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);

        int num, cont;
        float num1, soma = 0;

        System.out.println("Quantos  números quer somar?");
        num = entrada.nextInt();

        for (cont = 0; cont < num; cont++) {
            System.out.println("Digite o número");
            num1 = entrada.nextFloat(); 
            soma += num1;
        } System.out.println("A soma de todos os números é: " + soma);
    }
}
