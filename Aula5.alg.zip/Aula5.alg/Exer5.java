import java.util.Scanner;
public class Exer5 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        String opc1;
        int opc;
        float num, maior = 0, soma = 0;

        System.out.println("Algoritmo de soma!");
        System.out.println("Digite a opção desejada:\n1-Executar programa\n2-Encerrar");
        opc = entrada.nextInt();

        while (opc == 1) {
            System.out.println("Digite um número");
            num = entrada.nextFloat();
            System.out.println("Deseja continuar [s/n]?");
            opc1 = entrada.next();
            soma += num;
            if (opc1.equals("n") && (num > maior)) {
                maior = num;
                System.out.println("O resultado da soma entre todos os números é: " + soma);
                System.out.println("Já o maior número digitado é: " + maior);
                break;   
            }
        }
    }
}
