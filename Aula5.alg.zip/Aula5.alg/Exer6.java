import java.util.Scanner;
public class Exer6 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        String opc1 = "s";
        int opc, neg = -0, pos = 0, i = 0;
        float num = 0, menor = -500;

        System.out.println("Algoritmo de múmeros Reais!");
        System.out.println("Digite a opção desejada:\n1-Executar programa\n2-Encerrar");
        opc = entrada.nextInt();

        if (opc == 1){
            while (opc1.equals("s")){
                System.out.print("Digite um número: ");
                num = entrada.nextFloat();
                i++;
                System.out.print("Deseja continuar? [s/n]: ");
                opc1 = entrada.next();

                if (i == 1){
                    menor = num;
                } if (num < 0){            
                    neg++;
                } if (num > 0){
                    pos++; 
                }
            }
            System.out.println("Números negativos digitados: " + neg);
            System.out.println("Números positivos digitados: " + pos);
            System.out.println("Já o menor número digitado foi: " + menor);     
        }
        System.out.print("Programa encerrado!"); 
    }    
}       