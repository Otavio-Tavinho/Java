import java.util.Scanner;
public class Exer7 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);

        String sexo = "", opc1 = "s";
        int opc, i = 0;
        float altura, medM = 0, medF = 0, soma = 0;

        System.out.println("Algoritmo para calcular média da altura!");
        System.out.println("Digite a opção desejada:\n1-Executar programa\n2-Encerrar");
        opc = entrada.nextInt();

        if (opc == 1){
            while (opc1.equals("s")){
                System.out.print("Qual seu sexo?: ");
                sexo = entrada.next();
                System.out.print("Qual sua altura?: ");
                altura = entrada.nextFloat();
                soma += altura;
                i++;
                System.out.print("Deseja continuar? [s/n]: ");
                opc1 = entrada.next();

                if (sexo.equals("Masculino")){
                    medM = soma / i;
                } if (sexo.equals("Feminino")){
                    medF = soma / i;
                }
            }
            System.out.println("A média da altura do sexo Masculino é: " + medM);
            System.out.println("A média da altura do sexo Feminino é: " + medF);     
        }
        System.out.print("Programa encerrado!");
    }
}
