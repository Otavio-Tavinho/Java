import java.util.Scanner;
public class Exer8 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);

        int neg = 0, pos = 0, i = 1;
        float nota, soma = 0, med = 0;

        while (i <= 80) {
            System.out.println("Digite sua nota?: ");
            nota = entrada.nextFloat();
            soma += nota;
            i++; 

            if (nota >= 6) {
                pos++;
            } else {
                neg++;
            }
        }
        med = soma / i; 
        System.out.println("Total de alunos aprovados: " + pos);
        System.out.println("Total de alunos reprovados: " + neg);
        System.out.println("Já a média total da turma é: " + med);
    }
}
