import java.util.Scanner;
public class Exer9 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);

        String opc = "s", sexo = "";
        int idade, i = 0, neg = 0, medI = 0, soma = 0;
        float salar = 0, somaS = 0, med = 0;

        
        do { 

            System.out.print("Qual sua idade?: ");
            idade = entrada.nextInt();
            soma += idade;

            if (idade < 1){
                System.out.println("Idade invalida!");
                break;
            } else {
                System.out.print("Qual seu sexo?: ");
                sexo = entrada.next();

                System.out.print("Qual seu salário?: ");
                salar = entrada.nextFloat();
                somaS += salar;
            
                i++;

                System.out.print("Deseja continuar? [s/n]: ");
                opc = entrada.next();

                if (idade > 0){
                    medI = soma / i;
                }
                if (sexo.equals("M")){
                    med = somaS / i;
                }
                if (sexo.equals("F") && (salar < 600)){
                    neg++;
                }
                
            }      

        System.out.println("A média de idade entre os intregantes do grupo é: " + medI);
        System.out.println("A média dos salários dos Homens é: " + med);
        System.out.println("A quantidade de mulheres com salários abaixo de R$ 600,00 é: " + neg);

        } while (opc.equals("s"));
    }
}
