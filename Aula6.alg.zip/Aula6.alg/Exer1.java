import java.util.Scanner;
public class Exer1{
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int anos, calc;

        System.out.print("Digite sua idade: ");
        anos = entrada.nextInt();
        calc = 360 * anos;

        System.out.println("Total de dias vivido é: " + calc);
    }
}