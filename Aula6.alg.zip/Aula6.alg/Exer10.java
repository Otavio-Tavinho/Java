import java.util.Scanner;
public class Exer10 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double salar, reaju;

        System.out.print("Digite seu salário: ");
        salar = entrada.nextFloat();

        if (salar < 1500){
            reaju = salar * 0.1;
            salar = salar + reaju; 
            System.out.print("Seu salário reajustado é: " + salar);
        } else if (salar >= 1500 && salar <= 3000){
            reaju = salar * 0.02;
            salar = salar + reaju;
            System.out.print("Seu salário reajustado é: " + salar);
        } else {
            System.out.print("Seu salário não tem reajuste!");
        }
    }
}
