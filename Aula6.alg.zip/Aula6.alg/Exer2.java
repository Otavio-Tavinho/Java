import java.util.Scanner;
public class Exer2{
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int i = 0, num;

        System.out.print("Digite um número inteiro qualquer: ");
        num = entrada.nextInt();

        for (i = 0; i <= num; i++){
            if (i%2==0){
                System.out.println("Os multiplo de 2 é: " + i);
            }   
        }

        System.out.println("----------------------");
        
        for (i = 0; i <= num; i++){
            if (i%3==0){
                System.out.println("Os multiplo de 3 é: " + i);
            }    
        }
        
        System.out.println("----------------------"); 
    }
}
