import java.util.Scanner;
public class Exer3 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int senha = 4531, num;

        System.out.print("Digite a senha de Acesso: ");
        num = entrada.nextInt();

        if (num == senha){
            System.out.println("Acesso liberado!");
        } else{
            System.out.print("Acesso negado!");
        }
    }
}
