import java.util.Scanner;
public class Exer4 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int i = 0, neg = 0, pos = 0, idade;

        for (i=0; i < 500; i++){
            System.out.print("Digite sua idade: ");
            idade = entrada.nextInt();

            if (idade >= 16){
                pos++; 
            }
            if (idade < 16){
                neg++;
            }
        }
        System.out.println("A quantidade de alunos que podem votar é: " + pos);
        System.out.println("A quantidade de alunos que não podem votar é: " + neg);
    }
}
