import java.util.Scanner;
public class Exer5 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        String prod = "", sex = "";
        int i, fem = 0, calc = 0;

        for (i=0; i < 6; i++){
            System.out.print("Qual seu sexo?: ");
            sex = entrada.next();
    
            System.out.print("Tem interesse no produto? [S/N]: ");
            prod = entrada.next();

            System.out.println("----------------------");

            if (sex.equals("F") && prod.equals("N")){
                fem++; 
            }
            if (prod.equals("S")){
                calc++;
            }
        }
        System.out.println("Quantidade total de pessoas que responderam sim é: " + calc);
        System.out.println("Quantidade total de mulheres que responderam não é: " + fem);
    }
}
