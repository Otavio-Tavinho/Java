public class Exer6 {
    public static void main (String[] args){

        int i = 1980;

        for (i=1980; i<=2024; i++){
            if ((i%4==0) && (i%100!=0) || i%400==0){   
                System.out.println(i + " é bissexto!");
            } else {
                System.out.println(i + " não é bissexto!");
            }
        }
    }
}
