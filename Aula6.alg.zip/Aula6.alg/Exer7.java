import java.util.Scanner;
public class Exer7 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int idade, calc;

        System.out.print("Qual seu ano de nascimento?: ");
        idade = entrada.nextInt();
        idade = 2023 - idade;
        calc = (2050 - 2023) + idade;
        System.out.println("Você tem: " + idade);
        System.out.println("E em 2050 você tera: " + calc)
        ;
    }
}
