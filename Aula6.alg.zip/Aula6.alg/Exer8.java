import java.util.Scanner;
public class Exer8 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double salar, vend, calc;

        System.out.print("Digite seu salário: ");
        salar = entrada.nextFloat();
        System.out.println("----------------------");
        System.out.print("Digite o valor total das suas vendas do mês: ");
        vend = entrada.nextInt();
        System.out.println("----------------------");
        calc = vend * 0.04;
        salar = salar + calc;
        System.out.print("O reajuste do salário é: " + salar);
    }
}
