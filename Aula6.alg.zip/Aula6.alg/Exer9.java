import java.util.Scanner;
public class Exer9 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        float num1, num2, calc;

        System.out.println("1-Adição\n2-Subtração\n3-Multiplicação\n4-Sair");
        int opc = entrada.nextInt();
        
        switch(opc) {
            case 1:
                System.out.println("Você escolheu Adição");
                System.out.print("Digite o primeiro número: ");
                num1 = entrada.nextFloat();
                System.out.print("Digite o segundo número: ");
                num2 = entrada.nextFloat();
                calc = num1 + num2;
                System.out.print("O resultado da soma é: " + calc);
                break;
            case 2:
                System.out.println("Você escolheu Subtração");
                System.out.print("Digite o primeiro número: ");
                num1 = entrada.nextFloat();
                System.out.print("Digite o segundo número: ");
                num2 = entrada.nextFloat();
                calc = num1 - num2;
                System.out.print("O resultado da subtração é: " + calc);
                break;
            case 3:
                System.out.println("Você escolheu Multiplicação");
                System.out.print("Digite o primeiro número: ");
                num1 = entrada.nextFloat();
                System.out.print("Digite o segundo número: ");
                num2 = entrada.nextFloat();
                calc = num1 * num2;
                System.out.print("O resultado da multiplicação é: " + calc);
                break;
                case 5:
                System.out.print("Você escolheu Sair");
                break;
            default:
                System.out.println("Opção invalida!");    
        }    
    }
}
