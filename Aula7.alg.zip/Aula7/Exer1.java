import java.util.Scanner;
public class Exer1{

    static void soma (int km_i, int km_f, int litros, int valor) {

        double dist_per = km_f - km_i;
        double consu_med = dist_per / litros;
        double valor_gas = litros * valor;

        System.out.println("Distância percorrida: " + dist_per);
        System.out.println("Consumo médio: " + consu_med);
        System.out.println("Preço gasto: " + valor_gas);
    }

    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double litros, valor;
        int km_i, km_f;


        System.out.print("Digite kilometrô inicial: ");
        km_i = entrada.nextInt();
        System.out.print("Digite kilometrô final: ");
        km_f = entrada.nextInt();
        System.out.print("Digite a quantidade de litro: ");
        litros = entrada.nextDouble();
        System.out.print("Digite o preço do litro: ");
        valor = entrada.nextDouble();

        soma(km_i, km_f, km_i, km_f);
    }
}