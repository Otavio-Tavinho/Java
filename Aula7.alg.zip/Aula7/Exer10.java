import java.util.Scanner;
public class Exer10 {
    static void converteDolar (double reais, double dollar){
        double cotaçao = reais / dollar; // ou reais * dollar(0,20) foi o que eu intendi no enunciado sorry.
        System.out.print("A conversão de Reais em Dólar é de US$: " + cotaçao + " Dollar");
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double reais, dollar;

        System.out.print("Digite um valor em Rais para converter em Dólar: ");
        reais = entrada.nextDouble();
        System.out.print("Digite o valor da cotação do Dólar: ");
        dollar = entrada.nextDouble();

        converteDolar(reais, dollar);
    }
}
