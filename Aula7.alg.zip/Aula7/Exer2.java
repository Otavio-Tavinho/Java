import java.util.Scanner;
public class Exer2 {

    static double soma (double altura, double base){
        double area = altura * base;
        return area;
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double altura, base;

        System.out.print("Digite a altura: ");
        altura = entrada.nextDouble();
        System.out.print("Digite a base: ");
        base = entrada.nextDouble();

        double result = soma(altura, base);
        System.out.print(result);
    }
}
