import java.util.Scanner;
public class Exer3 {
    static double soma (double valor_comp, int num_parc){
        double valor_parc = valor_comp / num_parc;
        System.out.println("O valor da parcela é de: " + valor_parc);
        double calc = 0.05 * valor_comp;
        double total =  calc + valor_comp;
        System.out.println("com o juros de 5%, teve um aumento de: " + calc);
        return total;
    }   
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double valor_comp;
        int num_parc;

        System.out.print("Digite o valor da compra: ");
        valor_comp = entrada.nextDouble();
        System.out.print("Digite o número de parcelas: ");
        num_parc = entrada.nextInt();

        double result = soma(valor_comp, num_parc);
        System.out.println("Valor total mais os juros: " + result);
    } 
}
