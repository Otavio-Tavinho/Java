import java.util.Scanner;
public class Exer4 {
    static void soma (double A, double B, double C){
        double Delta = (B * B) - (4 * A * C);

        if (Delta >= 0){
            double x1 = (-B + Math.sqrt(Delta)) / (2 * A);
            double x2 = (-B - Math.sqrt(Delta)) / (2 * A); 
            System.out.print("As raizes são reais: " + x1 + x2);
        } 
        else {
            System.out.print("As raizes não são reais!");
        }
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double A, B, C;

        System.out.print("Digite o valor do A: ");
        A = entrada.nextDouble();
        System.out.print("Digite o valor do B: ");
        B = entrada.nextDouble();
        System.out.print("Digite o valor do C: ");
        C = entrada.nextDouble();

        soma(A, B, C);
    }
}
