import java.util.Scanner;
public class Exer5 {
    static double soma (double veloc_in, double acel, double temp) {
        double calc = veloc_in + acel * temp;
        return calc;
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double veloc_in, acel, temp;
        int i = 1;

        for (i = 1; i <= 3; i++) {
            System.out.print("Digite a velocidade inicial: ");
            veloc_in = entrada.nextDouble();
            System.out.print("Digite a aceleração: ");
            acel = entrada.nextDouble();
            System.out.print("Digite o tempo: ");
            temp = entrada.nextDouble();
            
            double result = soma(veloc_in, acel, temp);
            System.out.println(result);
        }
    }
}
