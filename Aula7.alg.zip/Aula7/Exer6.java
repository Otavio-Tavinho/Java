import java.util.Scanner;
public class Exer6 {
    static void soma (double produto){
        double juros = produto * 0.09;
        double total = juros + produto;

        System.out.println("O valor do produto com o juros de 9% é de: " + total);
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double produto;

        System.out.print("Digite o valor do produto: ");
        produto = entrada.nextDouble();

        soma(produto);
    }
}
