import java.util.Scanner;
public class Exer7 {
    static void soma (int prego_t, int prego_q){
        double telheiro = prego_t * 1.05;
        double quadrado = prego_q * 0.51;
        double total = telheiro + quadrado;
        double comissao = total * 0.1;
         System.out.println("Total arrecadado: " + total);
          System.out.println("Comissão arrecadada: " + comissao);
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int prego_t, prego_q;

        System.out.print("Digite quantos pregos Telheiro foram vendidos: ");
        prego_t = entrada.nextInt();
        System.out.print("Digite quantos pregos Quadrado foram vendidos: ");
        prego_q = entrada.nextInt();

        soma(prego_t, prego_q);
    }
}
