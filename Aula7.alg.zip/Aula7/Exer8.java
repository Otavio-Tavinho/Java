import java.util.Scanner;
public class Exer8 {
    static void valorCofre (double vinte_cinco, double dez, double cinco){
        double total = vinte_cinco + dez + cinco;
        System.out.println("Você tem armazenado um total de R$: " + total + " Reais");
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

       int vinte_cinco, dez, cinco;
       
       System.out.print("Digite quantas moedas de 25 tem no cofre: ");
       vinte_cinco = entrada.nextInt();
       System.out.print("Digite quantas moedas de 10 tem no cofre: ");
       dez = entrada.nextInt();
       System.out.print("Digite quantas moedas de 25 tem no cofre: ");
       cinco = entrada.nextInt();       

       valorCofre(vinte_cinco, dez, cinco);
    }
    
}
