import java.util.Scanner;
public class Exer9 {
    static void soma (double altura, double peso){
        double imc = peso / Math.pow(altura, 2);
        System.out.println("O indice de IMC é: " + imc);
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double altura, peso;

        System.out.print("Digite a altura: ");
        altura = entrada.nextDouble();
        System.out.print("Digite o peso: ");
        peso = entrada.nextDouble();

        soma(altura, peso);
    }
    
}
