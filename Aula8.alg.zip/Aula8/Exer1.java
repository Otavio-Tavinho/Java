import java.util.Scanner;
public class Exer1{
    static double soma (double raio){
        double area = Math.PI * Math.pow(raio, 2);
        return area;
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double raio;

        System.out.print("Digite o raio do circulo: ");
        raio = entrada.nextDouble();

        double result = soma(raio);
        System.out.print("A area do circulo é: " + result);
    }
}