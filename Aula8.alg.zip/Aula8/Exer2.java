import java.util.Scanner;
public class Exer2{
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double temp, media, maior = 0, menor = 0, soma = 0;
        int mes, mesMaisQ, mesMenosQ;

        
        for (mes = 1; mes <= 12; mes++){
            System.out.println("Digite a temperatura do mês " + mes);
            temp = entrada.nextDouble();
            soma += temp;

            if (mes == 1){
                maior = temp;
                mesMaisQ = mes;
                menor = temp;
                mesMenosQ = mes;
            }
            if (temp > maior){
                maior = temp;
                mesMaisQ = mes;
            }
            if (temp < menor){
                menor = temp;
                mesMenosQ = mes;
            }
        }

        media = soma/12;
        System.out.println("A média das temperaturas do ano é " + media);
        System.out.println("A maior temperatura do ano foi " + maior);
        System.out.println("A menor temperatura do ano foi " + menor);
    }
}