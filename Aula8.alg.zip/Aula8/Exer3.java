import java.util.Scanner;
public class Exer3 {
    static void soma (double juros, double deposito){
        double taxa = juros / 100;
        double calc = taxa * deposito;
        double total = calc + deposito;
        
        System.out.println("O rendimento vai ser de: " + calc);
        System.out.println("O valor total: " + total);
    }
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        double juros, deposito;

        System.out.print("Digite o valor do deposito: ");
        deposito = entrada.nextDouble();
        System.out.print("Digite a taxa de juros: ");
        juros = entrada.nextDouble();

        soma(juros, deposito);
    }
}
