import java.util.Scanner;
public class Exer4 {
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        int num, cent, dez, uni;

        System.out.println("Digite um número inteiro menor que 1000");
        num = entrada.nextInt();

        if (num >= 1000){
            System.out.println("Número inválido");
        } 
        else {
            cent = num / 100;
            dez = num % 100/10;
            uni = num % 10;
            System.out.println(cent + " centenas " + dez + " dezenas " + uni + " unidades");
        }
    }
}
