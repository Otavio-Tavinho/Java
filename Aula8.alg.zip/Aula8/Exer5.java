import java.util.Scanner;
public class Exer5{
    public static void main (String[] args){
        Scanner entrada  = new Scanner (System.in);

        String resp;
        int cont = 0;


        System.out.println("Telefonou para a vítima?");
        resp = entrada.next();

        if (resp.equals("s") || resp.equals("S")){
            cont++;
            System.out.println("Esteve no local do crime?");
            resp = entrada.next();
        }
        if (resp.equals("s") || resp.equals("S")){
            cont++;
            System.out.println("Mora perto da vítima");
            resp = entrada.next();
        }            
        if (resp.equals("s") || resp.equals("S")){
            cont++;
            System.out.println("Devia $$ para a vítima");
            resp = entrada.next();
        }
        if (resp.equals("s") || resp.equals("S")){
            cont++;
            System.out.println("Já trabalhou com a vítima");
            resp = entrada.next();
        }
        if (resp.equals("s") || resp.equals("S")){
            cont++;
        }
        if (cont == 2){
            System.out.println("Você é suspeito");
        }
        else if (cont == 3 || cont == 4){
            System.out.println("Você é cúmplice");
        }
        else if (cont == 5){
            System.out.println("Parabéns você é o assassino");
        }
        else {
            System.out.println("Que pena você é inocente");
        }
    }       
}