public class Exer1{
    public static void main (String[] args){

        int med, n[] = {10, 20, 30, 40, 50};

        med = n[2] + n[3] + n[4] / 3;

        System.out.println("A menor quantidade de vendas é: " + n[0]);
        System.out.println("A maior quantidade de vendas é: " + n[4]);
        System.out.println("A média superada vendida é: " + med + " dias");
    }
}