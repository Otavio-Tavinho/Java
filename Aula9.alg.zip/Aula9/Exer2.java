import java.util.Scanner;
public class Exer2 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);
        double n[] = new double[10];
        
        double med;

        for (int i = 0; i < 10; i++){
            System.out.print("Digite um número: ");
            n[i] = entrada.nextInt();
        }

        med = (n[0]+n[1]+n[2]+n[3]+n[4]+n[5]+n[6]+n[7]+n[8]) / n[9];
        n[9] = med;

        System.out.println("A média entre todos os vetores é: " + med);

         for (int i = 0; i < 10; i++){
            System.out.println(n[i]);
        }
    }   
}
