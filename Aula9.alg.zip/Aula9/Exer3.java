import java.util.Scanner;
public class Exer3 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);

        String opc = "";
        int med = 0, i = 0, user = 100;
        double soma = 0;
        double n[] = new double[user];


        do{
            i++;
            System.out.print("Digite um número: ");
            n[i] = entrada.nextInt();
            soma = soma + n[i];

            if (n[i] < 50){
                med++;
            }
    
            System.out.print("Deseja continuar: [s/n]? ");
            opc = entrada.next();
        } while (opc.equals("s")|| opc.equals("S"));

        System.out.println("Calculo de todos os números armazenados: " + soma);
        System.out.println("Quantidade de números acima da média: " + med);
    }
}        