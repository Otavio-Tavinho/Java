import java.util.Scanner;
public class Exer4 {
    public static void main(String[] args){
        Scanner entrada = new Scanner(System.in);

        String opc = "";
        int i = 0, med = 0, curso = 0, user = 100;
        double medA = 0, soma = 0;
        String n[] = new String[user];
        String n1[] = new String[user];
        double n2[] = new double[user];

        do{
            i++;
            System.out.print("Digite o seu primeiro nome: ");
            n[i] = entrada.next();

            System.out.print("Digite o nome do seu curso: [ccp/tads]? ");
            n1[i] = entrada.next();

            System.out.print("Digite a sua nota: ");
            n2[i] = entrada.nextDouble();
            soma = soma + n2[i];
            medA = soma / i;

            if (n1[i].equals("tads") || n1[i].equals("TADS")) {
                curso++;
            }
            if (n2[i] >= 6) {
                med++;
            }
    
            System.out.print("Deseja continuar: [s/n]? ");
            opc = entrada.next();
        } while (opc.equals("s")|| opc.equals("S"));

        System.out.println("Quantidade de alunos do curso de tads é: " + curso);
        System.out.println("A media dos alunos é: " + medA);
        System.out.println("Quantidade de alunos acima da média é: " + med);
    }
}            