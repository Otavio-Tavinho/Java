package aluno;
import java.text.DecimalFormat;
import java.util.Scanner;
public class Aluno {
    public static void main(String[] args) {
        DecimalFormat decimal = new DecimalFormat("0.00");
        Scanner input = new Scanner(System.in);
        
        String nome;
        int rmg;
        double soma=0, notas;
        
        System.out.print("Digite seu nome: ");
        nome = input.nextLine();
        System.out.print("Digite seu RMG: ");
        rmg = input.nextInt();
        
        System.out.print("Insira o valor do vetor para calcular suas notas: ");
        int vetor = input.nextInt();
        
        for(int i=0; i<vetor; i++){
            System.out.print("Insira suas notas: ");
            double media[] = new double[vetor];
            media[i] = input.nextDouble();
            soma += media[i];
        }
        
        notas = soma / vetor;
        AtributosAluno dadosAluno = new AtributosAluno(nome, rmg, notas); 
        
        System.out.println("Olá "+dadosAluno.nome);
        System.out.println("Seu RMG é: "+dadosAluno.rgm);
        dadosAluno.notas();
        System.out.println("A sua média final é: "+dadosAluno.notas);
        
        /* Obs: dadosAluno é classe e vc pode usar quantas quiser..
        * Exemplo: dadosAluno1, dadosAluno2 etc. 
        */
    }   
}