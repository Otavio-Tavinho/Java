package aluno;
public class AtributosAluno {
    String nome;
    int rgm;
    double notas;

    public AtributosAluno(String nome, int rgm, double notas) {
        this.nome = nome;
        this.rgm = rgm;
        this.notas = notas;
    }
    
    public void notas(){
        if(notas>=6){
            System.out.println("Aprovado!");
        } else {
            System.out.println("Reprovado!");
        }
    }
}
