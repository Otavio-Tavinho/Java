package carro;
public class AtributosCarro {
    private String marca, modelo;
    private double velocidadeAtual;

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getVelocidadeAtual() {
        return velocidadeAtual;
    }

    public void setVelocidadeAtual(double velocidadeAtual) {
        this.velocidadeAtual = velocidadeAtual;
    }
    
    public void frear(double carroParou){
        if(velocidadeAtual>0){
            carroParou = velocidadeAtual - velocidadeAtual;
            System.out.println("Você freou! \n"+carroParou+"'KM Carro Parado!");
        }
    }
    
    public void acelerar(double carroAcelera){
        if(velocidadeAtual>0){
            carroAcelera = velocidadeAtual + velocidadeAtual;
            System.out.println("Você acelerou! \nvelocidade atual é de: "+carroAcelera+"'KM por hora!");
        }
    }
}
