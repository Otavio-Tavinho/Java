package carro;
import java.text.DecimalFormat;
import java.util.Scanner;
public class Carro {
    public static void main(String[] args) {
        DecimalFormat decimal = new DecimalFormat("0.00");
        Scanner input = new Scanner(System.in);
        
        String marca, modelo;
        double velocidadeAtual;
        
        AtributosCarro marcaCarro = new AtributosCarro();
        AtributosCarro modeloCarro = new AtributosCarro();
        AtributosCarro velocidadeCarro = new AtributosCarro();
        
        System.out.print("Digite a marca do carro: ");
        marca = input.nextLine();
        marcaCarro.setMarca(marca);
        
        System.out.print("Digite o modelo do carro: ");
        modelo = input.nextLine();
        modeloCarro.setModelo(modelo);
        
        System.out.print("Digite a valocidade atual do carro: ");
        velocidadeAtual = input.nextDouble();
        velocidadeCarro.setVelocidadeAtual(velocidadeAtual);
       
        System.out.println("Seu carro está a "+velocidadeCarro.getVelocidadeAtual()+"'KM por hora!");
        
        System.out.print("Digite a opção desejada \n1-acelerar\n2-frear\n");
        int opc = input.nextInt();
        
        switch(opc){
            case 1:
                velocidadeCarro.acelerar(velocidadeAtual);
                break;
            case 2:
                velocidadeCarro.frear(velocidadeAtual);
                break;
        }
    }
    
}
