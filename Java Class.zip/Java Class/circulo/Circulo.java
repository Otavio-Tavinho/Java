package circulo;
import java.text.DecimalFormat;
import java.util.Scanner;
public class Circulo {
    public static void main(String[] args) {
        DecimalFormat decimal = new DecimalFormat("0.00");
        Scanner input  = new Scanner (System.in);
       
        System.out.print("Digite o raio do circulo: ");
        double raio = input.nextDouble();
        SomaCirculo circulo = new SomaCirculo(raio);
        
        System.out.println("A área do círculo é: " + decimal.format(circulo.soma()));
    }
}
