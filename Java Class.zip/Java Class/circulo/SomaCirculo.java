package circulo;
public class SomaCirculo {
    double raio;

    public SomaCirculo(double raio){
        this.raio = raio;
    }
    
    public double soma(){
         return Math.PI * Math.pow(raio, 2);
    }
}
