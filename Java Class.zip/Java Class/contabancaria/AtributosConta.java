package contabancaria;
public class AtributosConta {
    String nome;
    int conta; 
    double saldo;
    
    public AtributosConta(String nome, int conta, double saldo){
        this.nome = nome;
        this.conta = conta;
        this.saldo = saldo;
    }
    
    public double deposito(double valor){
        valor = valor + saldo;
        return valor;
    }
    public double saque(double valor){
        valor = saldo - valor;
        return valor;
    }
}