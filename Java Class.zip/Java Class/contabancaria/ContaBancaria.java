package contabancaria;
import java.util.Scanner;
public class ContaBancaria {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
       
        String nome; 
        int opc, conta; 
        double valor, saldo; 
        
        System.out.print("Digite seu nome: ");
        nome = entrada.next();
        System.out.print("Digite o numero da sua conta: ");
        conta = entrada.nextInt();
        System.out.print("Digite o saldo da sua conta: ");
        saldo = entrada.nextDouble();
        AtributosConta dadosbancario = new AtributosConta(nome, conta, saldo);
        
        System.out.println("O nome do titular da conta bancária é: " + dadosbancario.nome);
        System.out.println("O número da conta bancária é: " + dadosbancario.conta);
        System.out.println("O saldo da conta bancária é: " + dadosbancario.saldo);
        
        System.out.print("Digite o numero desejado para realizar a operação");
        System.out.print("\n1-Depositar\n2-Sacar\n3-Sair\n");
        opc = entrada.nextInt();
        
        switch(opc){
            case 1:
                System.out.print("Digite o valor do deposito: ");
                valor = entrada.nextDouble();
                dadosbancario.deposito(valor);
                System.out.println(dadosbancario.deposito(valor));
                break;
            case 2:
                System.out.print("Digite o valor do saque: ");
                valor = entrada.nextDouble();
                dadosbancario.saque(valor);
                System.out.println(dadosbancario.saque(valor));
                break;
            case 3:
                System.out.println("Obrigado, lhe vejo em breve!");
                break;
            default:
                System.out.println("Opção invalida!");    
        }
    }
}
