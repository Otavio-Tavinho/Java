package funcionario;
import java.text.DecimalFormat;
import java.util.Scanner;
public class AtributosFuncionario {
    String nome, cargo;
    double salario;
    
    public AtributosFuncionario(String nome, String cargo, double salario){
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }
    
    public void salarioLiquido(double salario, double desconto_inss, double desconto_beneficio){
        Scanner input = new Scanner(System.in);
        DecimalFormat decimal = new DecimalFormat("0.00");
        
        String opc; 
        int beneficio;
        
        if(salario<=1212.01){
            desconto_inss = salario * 0.075;
            salario = salario - desconto_inss;
        }
        if(salario>1212.01 || salario<=2427.35){
            desconto_inss = salario * 0.09;
            salario = salario - desconto_inss;
        }
        if(salario>2427.35 || salario<=3641.03){
            desconto_inss = salario * 0.12;
            salario = salario - desconto_inss;
        }
        if(salario>3641.03){
            desconto_inss = salario * 0.14;
            salario = salario - desconto_inss;
        }
        
        System.out.print("Você recebe algum benefício [s/n]: ");
        opc = input.next();
        
        if (opc.equals("s") || opc.equals("s")){
            
            System.out.print("Escolha na opção o número do seu benefício:");
            System.out.print("\n1-Vale-Transporte\n2-Odontológico\n3-Médico\n4-Sair\n");
            beneficio = input.nextInt();
            
            switch(beneficio){
                case 1:
                    desconto_beneficio = salario  * 0.06;
                    salario = salario - desconto_beneficio;
                    System.out.println("Seu salário liquído é: " + decimal.format(salario));
                    break;
                case 2:
                    desconto_beneficio = salario  * 0.3;
                    salario = salario - desconto_beneficio;
                    System.out.println("Seu salário liquído é: " + decimal.format(salario));
                    break;
                case 3:
                    desconto_beneficio = salario  * 0.4;
                    salario = salario - desconto_beneficio;
                    System.out.println("Seu salário liquído é: " + decimal.format(salario));
                    break;
                case 4:
                    System.out.println("Obrigado, volte sempre!");
                    break;    
                default:
                    System.out.println("Opção invalida!");    
            }
        } else {
            System.out.println("Seu salário liquído é: " + decimal.format(salario));
        } 
    }                  
}
