package funcionario;
import java.util.Scanner;
public class Funcionario {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String nome, cargo;
        double salario;
        
        System.out.print("Digite seu nome: ");
        nome = input.next();
        System.out.print("Digite seu cargo: ");
        cargo = input.next();
        System.out.print("Digite seu salário: ");
        salario = input.nextDouble();
        AtributosFuncionario funcionario = new AtributosFuncionario(nome, cargo, salario);
        
        System.out.println("Seu nome é: " + funcionario.nome);
        System.out.println("Seu cargo é: " + funcionario.cargo);
        System.out.println("Seu salário é: " + funcionario.salario);
        funcionario.salarioLiquido(salario, salario, salario);
    }
}
