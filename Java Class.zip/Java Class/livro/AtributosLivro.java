package livro;

import java.util.Scanner;

public class AtributosLivro {
    private String titulo[];
    private String autor[];
    private int vet, paginas[];

    public int getVet() {
        return vet;
    }

    public void setVet(int vet) {
        this.vet = vet;
    }

    public String[] getTitulo() {
        return titulo;
    }

    public void setTitulo(String[] titulo) {
        this.titulo = titulo;
    }

    public String[] getAutor() {
        return autor;
    }

    public void setAutor(String[] autor) {
        this.autor = autor;
    }

    public int[] getPaginas() {
        return paginas;
    }

    public void setPaginas(int[] paginas) {
        this.paginas = paginas;
    }
    
    public void vetor(){
        Scanner input = new Scanner(System.in);
        
        System.out.print("Insira o tamanho do vetor: ");
        vet = input.nextInt();
    }
    
    public void tituloLivro(){
        Scanner input = new Scanner(System.in);
        
        this.titulo = new String[vet];
        
        for(int i=0; i<vet; i++){
            System.out.print("Digite o ["+(i+1)+"°] título do livro: ");
            titulo[i] = input.nextLine();
            System.out.print("");
            
            System.out.println(titulo[i]+" armazenado!");
        }    
    }
    
    public void autorLivro(){
        Scanner input = new Scanner(System.in);
        
        this.autor = new String[vet];
        
        for(int i=0; i<vet; i++){
            System.out.print("Digite o nome do ["+(i+1)+"°] autor: ");
            autor[i] = input.nextLine();
            System.out.print("");
            
            System.out.println("Nome do autor "+autor[i]+" armazenado!");
        }
    }
    
    public void paginasLivro(){
        Scanner input = new Scanner(System.in);
        
        this.paginas = new int[vet];
        
        for(int i=0; i<vet; i++){
            System.out.print("Digite o número de páginas do ["+(i+1)+"°] livro: ");
            paginas[i] = input.nextInt();
        }
    }
    
    public void tituloDisponivel(){
        System.out.println("Títulos disponíveis!");
        for(int i=0; i<vet; i++){
            System.out.println("["+(i+1)+"°] "+titulo[i]);
        }
    }
    
    public void menuBiblioteca(){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Insira o valor da opção desejada: "
                + "\n1-Pegar Emprestado \n2-Devolver \n3-Títulos Disponíveis");
        int opc = input.nextInt();
            
        switch(opc){
            case 1:
                System.out.println("Você Pegou Emprestado!");
                break;
            case 2:
                devolver();
                break;
            case 3:
                tituloDisponivel();
                System.out.print("Deseja pegar emprestado? [s/n]: ");
                String menu = input.next();
                if(menu.equals("s") || menu.equals("S")){
                    System.out.println("Você Pegou Emprestado!");
                } else {
                    System.out.println("Obrigado, volte sempre!");
                }   
                break;
            default:
                System.out.println("Opção invalida!");     
        }
    }
    
    public void devolver(){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Você devolveu, Obrigado!");
        
    }
}
