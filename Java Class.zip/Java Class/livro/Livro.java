package livro;
public class Livro {
 public static void main(String[] args) {
        AtributosLivro biblioteca = new AtributosLivro();
        
        biblioteca.vetor();
        biblioteca.tituloLivro();
        biblioteca.autorLivro();
        
        System.out.println("Sua biblioteca está pronta!");
        
        biblioteca.menuBiblioteca();
    }
    
}
