package paciente;
import java.util.Scanner;
public class AtributosPaciente {
    private String nome;
    private String historico[];
    private int idade;
    private int vet, vet2;

    public int getVet() {
        return vet;
    }

    public void setVet(int vet) {
        this.vet = vet;
    }

    public int getVet2() {
        return vet2;
    }

    public void setVet2(int vet2) {
        this.vet2 = vet2;
    }

    public String[] getHistorico() {
        return historico;
    }

    public void setHistorico(String[] historico) {
        this.historico = historico;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }  
    
    public void histoConsultas(String historico[]){
        Scanner input = new Scanner(System.in);
        
        System.out.print("Insira o número de consultas no seu historico: ");
        this.vet = input.nextInt();
        historico = new String[vet];
        
        for(int i=0; i<vet; i++){
            System.out.print("Insira o nome do ["+(i+1)+"°] exame: ");
            historico[i] = input.next();
            System.out.println("Exame de "+historico[i]+ " realizado!");
        }
    }
    
    public void novConsultas(String consultas[]){
        Scanner input = new Scanner(System.in);
        
        int i=0;
        
        System.out.print("Deseja adicionar um novo exame ao historico?[s/n]: ");
        String opc = input.next();
        
        if(opc.equals("s") || opc.equals("S")){
            System.out.print("Insira valor da quantidade de novos exames: ");
            this.vet2 = input.nextInt();
            consultas = new String[vet2];
            
            for(i=0; i<vet2; i++){
                System.out.print("Insira o nome do novo exame ["+(i+1)+"°]: ");
                consultas[i] = input.next(); 
                System.out.println("Exame de "+consultas[i]+ " realizado!");
            }
        } else {
            System.out.println("Obrigado, vejo você mais tarde!");
        }    
    } 
    public void listaConsulta(){
        int lista = this.vet + this.vet2;
        System.out.println("Você tem no seu Histórico "+lista+" consultas realizadas!");
    }
}
