package paciente;

import java.util.Scanner;

public class Paciente {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        String nome;
        int idade;
        
        AtributosPaciente dadosPaciente = new AtributosPaciente();
        
        System.out.print("Digite seu nome: ");
        nome = input.nextLine();
        System.out.print("");
        dadosPaciente.setNome(nome);
        
        System.out.print("Digite sua idade: ");
        idade = input.nextInt();
        dadosPaciente.setIdade(idade);
        
        System.out.println("Olá "+dadosPaciente.getNome());
        System.out.println("Você esta com "+dadosPaciente.getIdade()+" anos!");
        
        dadosPaciente.histoConsultas(args);
        dadosPaciente.novConsultas(args);
        dadosPaciente.listaConsulta();
        
        
        
    }
}
