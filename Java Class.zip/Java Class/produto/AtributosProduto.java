package produto;

import java.text.DecimalFormat;
import java.util.Scanner;

public class AtributosProduto {
    private String nome[];
    private int vet, quantidade[];
    private double s2, preço[];

    public double getS2() {
        return s2;
    }

    public void setS2(double s2) {
        this.s2 = s2;
    }

    public int getVet() {
        return vet;
    }

    public void setVet(int vet) {
        this.vet = vet;
    }

    public int[] getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int[] quantidade) {
        this.quantidade = quantidade;
    }

    public double[] getPreço() {
        return preço;
    }

    public void setPreço(double[] preço) {
        this.preço = preço;
    }

    public String[] getNome() {
        return nome;
    }

    public void setNome(String[] nome) {
        this.nome = nome;
    }
    
    public void vetor(){
        Scanner input = new Scanner(System.in);
        
        System.out.print("Insira o tamanho do vetor: ");
        this.vet = input.nextInt();
    }
    
    public void nomeProduto(){
        Scanner input = new Scanner(System.in);
        
        this.nome = new String[vet];
        
        for(int i=0; i<vet; i++){
            System.out.print("Digite o nome do ["+(i+1)+"°] produto: ");
            nome[i] = input.next();
        }    
    }
    
    public void quantProduto(){
        Scanner input = new Scanner(System.in);
        
        this.quantidade = new int[vet];
        
        for(int i=0; i<vet; i++){
            System.out.print("Digite a quantidade do ["+(i+1)+"°] produto: ");
            quantidade[i] = input.nextInt(); 
            
            if (quantidade[i]==0){
                System.out.println("Não temos ["+nome[i]+"] em estoque!");
            }
        }
    }
    
    public void preçoProduto(){
        Scanner input = new Scanner(System.in);
        
        this.preço = new double[vet];
        
        for(int i=0; i<vet; i++){
            if(quantidade[i]==0){
                break;
            } else {
                System.out.print("Insira o valor do ["+(i+1)+"°] produto: ");
                preço[i] = input.nextDouble();
                s2 += preço[i] * quantidade[i];
            }
        }
    }
    
    public void calculoProduto(){
        DecimalFormat decimal = new DecimalFormat("0.00");
        
        System.out.println("O valor total em estoque é R$: "+decimal.format(s2));
        System.out.println("Obrigado por utilizar este programa!");
    }
}
