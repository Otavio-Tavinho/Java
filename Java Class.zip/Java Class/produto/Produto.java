package produto;
public class Produto {
    public static void main(String[] args) {
        
        AtributosProduto estoque = new AtributosProduto();
        
        estoque.vetor();
        estoque.nomeProduto();
        estoque.quantProduto();
        estoque.preçoProduto();
        estoque.calculoProduto();
    }
}
