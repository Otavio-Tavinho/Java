package triangulo;
public class SomaTriangulo {
    double base, altura;
    
    public SomaTriangulo(double base, double altura){
        this.base = base;
        this.altura = altura;
    }
    
    public double soma(){
         return (base * altura)/2;
    }
}
