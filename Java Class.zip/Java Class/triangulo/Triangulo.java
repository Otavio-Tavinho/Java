package triangulo;
import java.util.Scanner;
public class Triangulo {
    public static void main(String[] args) {
        Scanner input  = new Scanner (System.in);
        
        double base, altura;
        
        System.out.print("Digite a base do triangulo: ");
        base = input.nextDouble();
        System.out.print("Digite a altura do triangulo: ");
        altura = input.nextDouble();
        SomaTriangulo triangulo = new SomaTriangulo(base, altura);
        
        System.out.println("A área do triângulo é: "+triangulo.soma());
    }
    
}
