package trianguloequilatero;
public class AtributosTriangulo {
    private double p1, p2, p3;

    public double getP1() {
        return p1;
    }

    public void setP1(double p1) {
        this.p1 = p1;
    }

    public double getP2() {
        return p2;
    }

    public void setP2(double p2) {
        this.p2 = p2;
    }

    public double getP3() {
        return p3;
    }

    public void setP3(double p3) {
        this.p3 = p3;
    }
    
    public void soma(double p1, double p2, double p3){
        if(p1+p2<p3 || p1+p3<p2 || p2+p3<p1){
            System.out.println("Não é um triângulo!");
        }
        else if(p1==p2 && p1==p3){
            System.out.println("Triângulo Equilatero");
        } 
        else if(p1==p2 || p1==p3 || p2==p3){
            System.out.print("Triângulo Isósceles");
        } else {
            System.out.println("Triângulo Escaleno");
        }
    }
}
