package trianguloequilatero;
import java.text.DecimalFormat;
import java.util.Scanner;
public class TrianguloEquilatero {
    public static void main(String[] args) {
        DecimalFormat decimal = new DecimalFormat("0.00");
        Scanner input = new Scanner(System.in);
        
        AtributosTriangulo ladoA = new AtributosTriangulo();
        AtributosTriangulo ladoB = new AtributosTriangulo();
        AtributosTriangulo ladoC = new AtributosTriangulo();
        AtributosTriangulo somaTriangulo = new AtributosTriangulo();
        
        double p1, p2, p3;
        
        
        System.out.print("Insira o valor do lado A: ");
        p1 = input.nextDouble();
        ladoA.setP1(p1);
        System.out.print("Insira o valor do lado B: ");
        p2 = input.nextDouble();
        ladoB.setP2(p2);
        System.out.print("Insira o valor do lado C: ");
        p3 = input.nextDouble();
        ladoC.setP3(p3);
        
        somaTriangulo.soma(p1, p2, p3);
    }
    
}
